# Translating INCY Tool

INCY Tool ships with English, Русский, 简体中文, 繁體中文, فارسی and Español.
Your language missing? You don't need to touch the code.

## Option 1 — right in the app (easiest, works on a phone)

1. Tap **🌐** (under the title) → **✍️ Create a translation**.
2. Enter the language code (`de`, `pt-BR`, `uk`, `sr-Latn`…) and its name in that language (`Deutsch`).
3. Translate as much as you like. Every string you leave empty is shown in the base language
   (the “Translate from” language), so a half-done translation already works.
4. **💾 Save & apply.** Unfinished work is kept as a draft even if you close the window.

Keep tags like `{n}`, `{name}`, `{app}` exactly as they are — the app puts numbers and names there.
Rows where a tag went missing are highlighted in red.

The same editor also fixes a built-in language: 🌐 → ✏️ next to it. Your edits are layered on top;
↺ removes them.

## Option 2 — a file

1. 🌐 → **📤 Template file** — downloads `incy-lang-template.incylang` (plain JSON, English values).
2. Set `_meta.code`, `_meta.name` (and `"dir": "rtl"` for right-to-left scripts), translate the `strings`.
3. 🌐 → **📂 File** (or paste a raw GitHub link and press **📥 URL**).

```json
{
  "_meta": { "code": "de", "name": "Deutsch", "dir": "ltr", "base": "en", "flag": "🇩🇪" },
  "strings": { "s1.badge": "Schritt 1: Quelle", "s1.paste": "📋 Einfügen" }
}
```

Only known keys and plain text are accepted; markup in translations is shown as text, never executed.

## Sharing a translation with everyone

🌐 → 📤 next to your language gives you the `.incylang` file. Open an issue or a pull request with it —
it gets added to `I18N_BUILTIN` in `index.html` and ships to all users.
