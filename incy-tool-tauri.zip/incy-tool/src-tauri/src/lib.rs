//! INCY Tool — десктоп-обёртка на Tauri 2.
//!
//! Интерфейс — тот же однофайловый index.html, что и в браузере. Rust нужен только для того,
//! чего страница в webview сама не умеет:
//!   • open_link      — передать incy:// / happ:// / свою схему системе (в webview `location.href` не работает);
//!   • save_text_file — системный диалог «Сохранить как» (скачивание blob в webview ненадёжно);
//!   • clip_read / clip_write — буфер обмена без запросов разрешений webview;
//!   • http_get       — скачать профиль/тему/перевод с сайта, который не отдаёт CORS-заголовки.
//!
//! JS-API плагинов наружу не открыт (в capabilities только core:default): даже чужой
//! плагин INCY Tool может делать лишь то, что разрешают эти четыре команды.

use std::net::IpAddr;
use std::time::Duration;

use tauri::AppHandle;
use tauri_plugin_clipboard_manager::ClipboardExt;
use tauri_plugin_dialog::DialogExt;
use tauri_plugin_opener::OpenerExt;

/// Схемы, которые нельзя отдавать системе: локальные файлы, скрипты и известные
/// «опасные» обработчики Windows (ms-msdt, search-ms и т.п.).
const BLOCKED_SCHEMES: &[&str] = &[
    "javascript", "data", "vbscript", "file", "blob", "about", "chrome", "edge",
    "search", "search-ms", "shell", "jar", "smb", "afp", "nfs", "ftp",
];

/// Ответ http_get не больше 5 МБ — профили и переводы весят килобайты.
const MAX_HTTP_BYTES: usize = 5 * 1024 * 1024;

fn url_scheme(url: &str) -> Option<String> {
    let idx = url.find(':')?;
    let scheme = &url[..idx];
    let mut chars = scheme.chars();
    if !chars.next()?.is_ascii_alphabetic() {
        return None;
    }
    if !chars.all(|c| c.is_ascii_alphanumeric() || c == '+' || c == '-' || c == '.') {
        return None;
    }
    Some(scheme.to_ascii_lowercase())
}

/// Открыть ссылку в приложении, зарегистрированном в системе для её схемы (INCY, Happ, браузер…).
#[tauri::command]
async fn open_link(app: AppHandle, url: String) -> Result<(), String> {
    let scheme = url_scheme(&url).ok_or_else(|| "bad url".to_string())?;
    if BLOCKED_SCHEMES.contains(&scheme.as_str()) || scheme.starts_with("ms-") {
        return Err(format!("scheme {scheme}: is blocked"));
    }
    if !url[scheme.len() + 1..].starts_with("//") {
        return Err("only scheme:// links are allowed".into());
    }
    app.opener()
        .open_url(url, None::<&str>)
        .map_err(|e| e.to_string())
}

/// Сохранить текст в файл, который пользователь выберет в системном диалоге.
/// Возвращает путь или None, если диалог закрыли.
#[tauri::command]
async fn save_text_file(
    app: AppHandle,
    file_name: String,
    contents: String,
) -> Result<Option<String>, String> {
    let ext = std::path::Path::new(&file_name)
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_string();

    let mut dialog = app.dialog().file().set_file_name(&file_name);
    if !ext.is_empty() {
        dialog = dialog.add_filter(ext.to_uppercase(), &[ext.as_str()]);
    }

    let Some(picked) = dialog.blocking_save_file() else {
        return Ok(None);
    };
    let path = picked.into_path().map_err(|e| e.to_string())?;
    std::fs::write(&path, contents).map_err(|e| e.to_string())?;
    Ok(Some(path.display().to_string()))
}

#[tauri::command]
fn clip_write(app: AppHandle, text: String) -> Result<(), String> {
    app.clipboard().write_text(text).map_err(|e| e.to_string())
}

#[tauri::command]
fn clip_read(app: AppHandle) -> Result<String, String> {
    app.clipboard().read_text().map_err(|e| e.to_string())
}

/// Адреса локальной сети и самой машины — их http_get не трогает,
/// чтобы плагин не мог через приложение достучаться до роутера или локальных сервисов.
fn is_local_host(url: &reqwest::Url) -> bool {
    let host = url
        .host_str()
        .unwrap_or("")
        .trim_start_matches('[')
        .trim_end_matches(']')
        .to_ascii_lowercase();
    if host.is_empty() {
        return true;
    }
    match host.parse::<IpAddr>() {
        Ok(IpAddr::V4(ip)) => {
            ip.is_loopback() || ip.is_private() || ip.is_link_local() || ip.is_unspecified()
                || ip.is_broadcast() || ip.octets()[0] == 100 && (ip.octets()[1] & 0xc0) == 64
        }
        Ok(IpAddr::V6(ip)) => {
            let first = ip.segments()[0];
            ip.is_loopback() || ip.is_unspecified()
                || (first & 0xfe00) == 0xfc00   // fc00::/7 — локальные
                || (first & 0xffc0) == 0xfe80   // fe80::/10 — link-local
                || ip.to_ipv4_mapped().map_or(false, |v4| v4.is_loopback() || v4.is_private())
        }
        Err(_) => host == "localhost" || host.ends_with(".localhost") || host.ends_with(".local"),
    }
}

/// GET по http(s) без cookies и без CORS-ограничений браузера. Только текст, до 5 МБ.
#[tauri::command]
async fn http_get(url: String) -> Result<String, String> {
    let parsed = reqwest::Url::parse(&url).map_err(|e| e.to_string())?;
    if parsed.scheme() != "https" && parsed.scheme() != "http" {
        return Err("only http(s) is allowed".into());
    }
    if is_local_host(&parsed) {
        return Err("local addresses are not allowed".into());
    }

    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(15))
        .user_agent(concat!("INCY-Tool/", env!("CARGO_PKG_VERSION")))
        .redirect(reqwest::redirect::Policy::custom(|attempt| {
            if attempt.previous().len() >= 5 || is_local_host(attempt.url()) {
                attempt.stop()
            } else {
                attempt.follow()
            }
        }))
        .build()
        .map_err(|e| e.to_string())?;

    let resp = client.get(parsed).send().await.map_err(|e| e.to_string())?;
    if !resp.status().is_success() {
        return Err(format!("HTTP {}", resp.status().as_u16()));
    }
    if resp.content_length().map_or(false, |len| len as usize > MAX_HTTP_BYTES) {
        return Err("response is too large".into());
    }
    let bytes = resp.bytes().await.map_err(|e| e.to_string())?;
    if bytes.len() > MAX_HTTP_BYTES {
        return Err("response is too large".into());
    }
    String::from_utf8(bytes.to_vec()).map_err(|_| "response is not text".to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .invoke_handler(tauri::generate_handler![
            open_link,
            save_text_file,
            clip_write,
            clip_read,
            http_get
        ])
        .run(tauri::generate_context!())
        .expect("error while running INCY Tool");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn schemes() {
        assert_eq!(url_scheme("incy://routing/onadd/abc").as_deref(), Some("incy"));
        assert_eq!(url_scheme("naive+https://x").as_deref(), Some("naive+https"));
        assert_eq!(url_scheme("1bad://x"), None);
        assert_eq!(url_scheme("no-colon"), None);
    }

    #[test]
    fn local_hosts() {
        let local = |u: &str| is_local_host(&reqwest::Url::parse(u).unwrap());
        assert!(local("http://127.0.0.1/"));
        assert!(local("http://192.168.1.1/"));
        assert!(local("http://[::1]/"));
        assert!(local("http://localhost:8080/"));
        assert!(local("http://router.local/"));
        assert!(!local("https://raw.githubusercontent.com/a/b"));
        assert!(!local("https://1.1.1.1/"));
    }
}
