// Без лишнего консольного окна на Windows в релизной сборке
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    incy_tool_lib::run()
}
