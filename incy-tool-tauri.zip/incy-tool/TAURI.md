# INCY Tool — десктоп-версия (Tauri 2)

Один и тот же `index.html` работает и как сайт, и как приложение для Windows / macOS / Linux.
Отдельной «десктопной» копии интерфейса нет: правишь `index.html` — меняются обе версии.

```
index.html              ← весь INCY Tool (это и есть веб-версия)
scripts/copy-web.mjs    ← кладёт index.html в dist/ перед сборкой
assets/app-icon.png     ← исходник иконки 1024×1024
src-tauri/
  src/lib.rs            ← 5 команд на Rust (ссылки, файлы, буфер, загрузка по сети)
  tauri.conf.json       ← окно, имя, иконки
  capabilities/         ← права страницы (только core:default)
.github/workflows/desktop.yml ← сборка установщиков в GitHub Actions
```

## Что нужно один раз

- **Node.js 18+** и **Rust** (`rustup`, https://rustup.rs)
- **Windows:** Microsoft C++ Build Tools (галочка «Desktop development with C++»). WebView2 уже есть в Windows 10/11.
- **macOS:** `xcode-select --install`
- **Linux (Debian/Ubuntu):**
  `sudo apt install libwebkit2gtk-4.1-dev libappindicator3-dev librsvg2-dev libxdo-dev build-essential`

## Команды

```bash
npm install        # один раз
npm run dev        # окно приложения с горячей перезагрузкой
npm run build      # установщики → src-tauri/target/release/bundle/
npm run icon       # пересобрать иконки из assets/app-icon.png
```

Первая сборка Rust идёт 5–10 минут, дальше — пара минут.

**Без своего компьютера под каждую ОС:** запушь тег (`git tag v1.0.0 && git push --tags`) —
GitHub Actions соберёт установщики для всех трёх систем и положит их в черновик релиза.
На macOS неподписанное приложение открывается через ПКМ → «Открыть».

## Чем приложение отличается от сайта

| Действие | В браузере | В приложении |
|---|---|---|
| «🚀 Открыть в INCY/Happ» | переход по `incy://…` | ссылка отдаётся системе (`open_link`); если приложения нет — копируется |
| «📥 Скачать», бэкап, темы, переводы | скачивание | системное окно «Сохранить как» (`save_text_file`) |
| «📋 Вставить» / копирование | `navigator.clipboard` | системный буфер без запросов (`clip_read`/`clip_write`) |
| Профиль/тема/перевод по ссылке | только сайты с CORS (GitHub raw) | любые сайты, в т.ч. Pastebin (`http_get`) |
| «☁️ Поделиться» | ссылка на текущую страницу | ссылка на веб-версию — впиши адрес в `INCY_WEB_URL` в `index.html` (или пользователь укажет его в окне) |

Определение среды — по `window.__TAURI_INTERNALS__`, в браузере весь этот код просто не срабатывает.

> ⚠️ Не называй глобальные переменные `isTauri`: Tauri 2 сам создаёт `window.isTauri`,
> и одноимённая `const` роняет весь скрипт в окне приложения (в Chrome этого не видно).

## Безопасность

- Странице открыт только `core:default`. JS-API плагинов Tauri (файлы, shell и т.п.) **не доступны** —
  даже чужой плагин INCY Tool может делать только то, что разрешают 5 команд из `lib.rs`.
- `open_link` не открывает `file:`, `javascript:`, `data:`, `ms-*` (известные эксплойты Windows) и ссылки без `scheme://`.
- `http_get` — только http(s), без cookies, до 5 МБ, 15 секунд, не ходит на `localhost` и в локальную сеть
  (включая редиректы туда).
- `save_text_file` пишет только в файл, который пользователь сам выбрал в системном диалоге.

## Новая версия

Поменяй номер в трёх местах: `package.json`, `src-tauri/Cargo.toml`, `src-tauri/tauri.conf.json`.
