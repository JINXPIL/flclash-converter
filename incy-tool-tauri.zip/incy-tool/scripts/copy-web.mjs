// Один исходник для веба и десктопа: index.html в корне копируется в dist/,
// откуда его берёт Tauri. Править нужно только корневой index.html.
import { mkdirSync, copyFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
mkdirSync(join(root, 'dist'), { recursive: true });
copyFileSync(join(root, 'index.html'), join(root, 'dist', 'index.html'));
console.log('index.html → dist/index.html');
